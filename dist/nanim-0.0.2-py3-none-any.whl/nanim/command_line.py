import nanim;

def main():
    print ("run nanim");
