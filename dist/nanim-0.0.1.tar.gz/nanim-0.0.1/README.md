#NAnim
## An animation library designed from the ground up for a intuitive and easy to use interface. Made in python.
